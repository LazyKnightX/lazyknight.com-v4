# W3x2Lni

[![Build Status](https://github.com/sumneko/w3x2lni/workflows/build/badge.svg)](https://github.com/sumneko/w3x2lni/actions?workflow=build)

* [文档](https://sumneko.github.io/w3x2lni/#/zh-cn/)
* [English Documents](https://sumneko.github.io/w3x2lni/#/en-us/)

## TODO

* 等级数据的压缩
* 地形文件
* 管理模型文件
* 自动生成暗图标
* 转换doo, w3s, w3r等文件
* 新UI
* 完善文档
