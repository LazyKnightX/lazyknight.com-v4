local fs = require 'bee.filesystem'

return fs.current_path():parent_path()
